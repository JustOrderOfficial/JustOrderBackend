package com.zosh.exception;

public class ProductException extends Exception{
	
	public ProductException(String message) {
		super(message);
	}

}
