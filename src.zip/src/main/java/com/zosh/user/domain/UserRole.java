package com.zosh.user.domain;

public enum UserRole {

	ROLE_ADMIN,
	ROLE_CUSTOMER
}
